import Database from 'better-sqlite3'
import path from 'node:path'
import { existsSync } from 'node:fs'

const dbPath = path.join(process.cwd(), 'tests', '.test-data', 'migrate-data', 'chesshub.db')
console.log('db:', dbPath, 'exists:', existsSync(dbPath))
if (!existsSync(dbPath)) process.exit(0)
const db = new Database(dbPath, { readonly: true })
console.log('tables:', db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all())
console.log('works:', db.prepare('SELECT * FROM works').all())
console.log('work_notes:', db.prepare('SELECT * FROM work_notes').all())
db.close()
