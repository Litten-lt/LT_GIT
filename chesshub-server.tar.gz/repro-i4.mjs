// Replicate I.4 manually: setup legacy DB + start server + POST note
import Database from 'better-sqlite3'
import { spawn } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { mkdir, rm, writeFile } from 'node:fs/promises'
import { setTimeout as sleep } from 'node:timers/promises'
import { Buffer } from 'node:buffer'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = __dirname  // script 在 chesshub-server/ 下, ROOT 就是它
const dataDir = path.join(ROOT, 'tests', '.test-data', 'repro-data')
const uploadDir = path.join(ROOT, 'tests', '.test-data', 'repro-uploads')

await rm(dataDir, { recursive: true, force: true })
await mkdir(dataDir, { recursive: true })
await mkdir(uploadDir, { recursive: true })

// 1. Setup legacy
const dbPath = path.join(dataDir, 'chesshub.db')
const db = new Database(dbPath)
db.exec(`
  CREATE TABLE works (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    problem TEXT, analysis TEXT, solution TEXT,
    tags TEXT NOT NULL DEFAULT '[]',
    images TEXT NOT NULL,
    date TEXT NOT NULL,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );
  INSERT INTO works (title, problem, analysis, solution, tags, images, date)
  VALUES ('legacy', 'p', 'a', 's', '[]', '[]', '2026.01');
`)
const id = db.prepare('SELECT id FROM works').get().id
console.log('legacy id:', id)
db.close()

// 2. Start server with debug log
const child = spawn(process.execPath, [path.join(ROOT, 'server.js')], {
  cwd: ROOT, env: {
    ...process.env, DATA_DIR: dataDir, UPLOAD_DIR: uploadDir,
    PORT: '30099', CORS_ORIGIN: '*', LOG_LEVEL: 'debug',
    JWT_SECRET: 'test', ADMIN_USER: 'admin', ADMIN_PASS: 'admin',
  }, stdio: ['ignore', 'pipe', 'pipe'],
})
let serverOut = ''
child.stdout.on('data', d => { serverOut += d.toString(); process.stdout.write('[srv] ' + d) })
child.stderr.on('data', d => { serverOut += d.toString(); process.stderr.write('[srv!] ' + d) })

await sleep(1500)

// 3. Login
const loginRes = await fetch('http://127.0.0.1:30099/api/auth/login', {
  method: 'POST', headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ username: 'admin', password: 'admin' }),
})
const { token } = await loginRes.json()
console.log('logged in, token:', token.slice(0, 20) + '...')

// 4. POST note via FormData
const fd = new FormData()
fd.append('content', '测试 note')
const res = await fetch(`http://127.0.0.1:30099/api/works/${id}/notes`, {
  method: 'POST',
  headers: { authorization: `Bearer ${token}` },
  body: fd,
})
console.log('POST status:', res.status)
console.log('POST body:', await res.text())

// 5. Check DB state
const db2 = new Database(dbPath, { readonly: true })
console.log('works:', db2.prepare('SELECT * FROM works').all())
console.log('work_notes:', db2.prepare('SELECT * FROM work_notes').all())
db2.close()

child.kill('SIGTERM')
await sleep(500)
console.log('=== server log ===')
console.log(serverOut)
