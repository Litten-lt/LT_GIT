// Verify DB state and try the exact same prepare
import Database from 'better-sqlite3'
import path from 'node:path'

const dbPath = path.join(process.cwd(), 'tests', '.test-data', 'repro-data', 'chesshub.db')
const db = new Database(dbPath, { readonly: true })
console.log('tables:', db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all())
console.log('works:', db.prepare('SELECT * FROM works').all())
try {
  console.log('work_notes count:', db.prepare('SELECT COUNT(*) AS n FROM work_notes').get())
} catch (e) {
  console.log('work_notes prepare failed:', e.message)
}
try {
  const stmt = db.prepare(`INSERT INTO work_notes (work_id, content, images) VALUES (?, ?, ?)`)
  console.log('INSERT INTO work_notes prepared OK')
} catch (e) {
  console.log('INSERT INTO work_notes prepare failed:', e.message)
}
db.close()
