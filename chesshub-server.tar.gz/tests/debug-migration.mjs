// Replicate I test setup + migration locally
import Database from 'better-sqlite3'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { mkdirSync, rmSync } from 'node:fs'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(__dirname, '..')
const dataDir = path.join(ROOT, 'tests', '.test-data', 'migrate-debug-data')
const uploadDir = path.join(ROOT, 'tests', '.test-data', 'migrate-debug-uploads')
rmSync(dataDir, { recursive: true, force: true })
mkdirSync(dataDir, { recursive: true })
mkdirSync(uploadDir, { recursive: true })

const dbPath = path.join(dataDir, 'chesshub.db')
console.log('[setup] db:', dbPath)
const db = new Database(dbPath)

db.exec(`
  CREATE TABLE works (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    problem     TEXT,
    analysis    TEXT,
    solution    TEXT,
    tags        TEXT NOT NULL DEFAULT '[]',
    images      TEXT NOT NULL,
    date        TEXT NOT NULL,
    created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );
  INSERT INTO works (title, problem, analysis, solution, tags, images, date)
  VALUES (
    '老 ticket 标题',
    '老现象: 设备启动慢',
    '老排查: dmesg 看了',
    '老解决: 换了 rootfs',
    '["OpenWrt","legacy"]',
    '[]',
    '2026.03'
  );
`)
const oldRow = db.prepare('SELECT id, title FROM works').get()
console.log('[setup] legacy id:', oldRow.id, 'title:', oldRow.title)

// Now run migration exactly as server.js does
const cols = db.prepare("PRAGMA table_info(works)").all().map(c => c.name)
console.log('[migrate] cols:', cols)
console.log('[migrate] has problem?', cols.includes('problem'))

if (cols.includes('problem')) {
  console.log('[migrate] running migration...')
  try {
    db.exec(`
      ALTER TABLE works RENAME TO _works_legacy;

      CREATE TABLE works (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        title       TEXT NOT NULL,
        description TEXT,
        date        TEXT NOT NULL,
        created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now')),
        updated_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
      );

      INSERT INTO works (id, title, description, date, created_at, updated_at)
      SELECT
        id,
        title,
        TRIM(COALESCE(
          (CASE WHEN problem IS NOT NULL AND problem != '' THEN '[现象]' || char(10) || problem || char(10) || char(10) ELSE '' END) ||
          (CASE WHEN analysis IS NOT NULL AND analysis != '' THEN '[排查]' || char(10) || analysis || char(10) || char(10) ELSE '' END) ||
          (CASE WHEN solution IS NOT NULL AND solution != '' THEN '[解决]' || char(10) || solution ELSE '' END),
          ''
        )),
        date,
        created_at,
        created_at
      FROM _works_legacy;

      DROP TABLE _works_legacy;
    `)
    console.log('[migrate] done')
  } catch (e) {
    console.error('[migrate] FAILED:', e.message)
  }
}

const final = db.prepare('SELECT * FROM works').all()
console.log('[verify] final works:', final)
db.close()
