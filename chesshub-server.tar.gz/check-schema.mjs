import Database from 'better-sqlite3'
import path from 'node:path'

const dbPath = path.join(process.cwd(), 'tests', '.test-data', 'repro-data', 'chesshub.db')
const db = new Database(dbPath, { readonly: true })
console.log('--- work_notes schema ---')
console.log(db.prepare("SELECT sql FROM sqlite_master WHERE name='work_notes'").get())
console.log('--- works schema ---')
console.log(db.prepare("SELECT sql FROM sqlite_master WHERE name='works'").get())
console.log('--- all sqlite_master ---')
console.log(db.prepare("SELECT type, name, sql FROM sqlite_master ORDER BY name").all())
db.close()
